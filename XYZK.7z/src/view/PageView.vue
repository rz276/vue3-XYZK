<template>
  <div id="container">
    <router-view />
  </div>
</template>

<script setup name="PageView"></script>

<style scoped></style>
