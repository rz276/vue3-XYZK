<template>
  <div id="smartTown">智能小镇管理系统</div>
</template>

<script setup name="smartTown"></script>

