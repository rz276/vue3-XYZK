<template>
  <div id="TeacherManagement">系统管理</div>
  <el-container class="card-container">
      <el-main>

      </el-main>
    </el-container>
</template>

<script setup name="TeacherManagement">

</script>

