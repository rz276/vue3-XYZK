<template>
  <div id="szkpj">师资库评价</div>

</template>

<script setup name="szkpj"></script>

