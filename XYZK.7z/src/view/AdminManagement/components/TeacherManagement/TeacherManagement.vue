<template>
  <div id="TeacherManagement">师资库管理</div>
  <el-container class="card-container">
      <el-main>

      </el-main>
    </el-container>
</template>

<script setup name="TeacherManagement">

</script>

