<template>
  <div id="CourseManagement">案例信息管理</div>
  <el-container class="card-container">
      <el-main>

      </el-main>
    </el-container>
</template>

<script setup name="CourseManagement">

</script>

