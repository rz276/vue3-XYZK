<template>
  <div id="szkpj">试题评价</div>

</template>

<script setup name="szkpj"></script>

