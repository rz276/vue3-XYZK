<template>
  <div id="TeacherManagement">试题库管理</div>
  <el-container class="card-container">

  </el-container>
</template>

<script setup name="TeacherManagement">

</script>

