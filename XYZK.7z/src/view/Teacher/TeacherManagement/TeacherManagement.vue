<template>
  <div id="TeacherManagement">师资库管理</div>
  <el-container class="card-container">
    <co />
  </el-container>
</template>

<script setup name="TeacherManagement">
import co from "../TeacherManagement/components/co.vue"
</script>

