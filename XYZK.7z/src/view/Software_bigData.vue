<template>
  <div id="Software">大数据管理系统</div>
</template>
<script setup name="bigData"></script>

